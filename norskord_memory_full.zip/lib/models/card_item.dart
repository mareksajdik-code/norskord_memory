class CardItem {
  final String text;
  final String pairId;
  bool revealed = false;
  bool matched = false;

  CardItem({required this.text, required this.pairId});
}
