import 'package:hive/hive.dart';
part 'deck.g.dart';

@HiveType(typeId: 1)
class CardPair {
  @HiveField(0)
  String no;
  @HiveField(1)
  String sk;
  @HiveField(2)
  int intervalDays;
  @HiveField(3)
  DateTime? nextReview;

  CardPair({required this.no, required this.sk, this.intervalDays = 0, this.nextReview});
}

@HiveType(typeId: 2)
class Deck extends HiveObject {
  @HiveField(0)
  String id;
  @HiveField(1)
  String name;
  @HiveField(2)
  List<CardPair> cards;

  Deck({required this.id, required this.name, required this.cards});
}
