import 'package:flutter/material.dart';

class CardWidget extends StatelessWidget {
  final String text;
  final bool revealed;
  final bool matched;
  final VoidCallback onTap;

  CardWidget({required this.text, required this.revealed, required this.matched, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: matched ? Colors.green.shade300 : revealed ? Colors.white : Colors.grey.shade400,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Center(child: Text(revealed || matched ? text : "")),
      ),
    );
  }
}
