import 'package:flutter/material.dart';
import '../data/word_sets.dart';
import 'game_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("NorskOrd Memory")),
      body: ListView(
        children: [
          ListTile(
            title: Text("Play: Default deck"),
            subtitle: Text("Quick session with sample words"),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => GameScreen(wordSetName: "Default")),
            ),
          ),
          ...wordSets.keys.map((key) {
            return ListTile(
              title: Text(key),
              trailing: Icon(Icons.arrow_forward),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => GameScreen(wordSetName: key),
                ),
              ),
            );
          }).toList(),
        ],
      ),
    );
  }
}
