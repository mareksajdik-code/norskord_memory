import 'dart:math';
import 'package:flutter/material.dart';
import '../models/card_item.dart';
import '../data/word_sets.dart';

class GameScreen extends StatefulWidget {
  final String wordSetName;
  GameScreen({required this.wordSetName});

  @override
  _GameScreenState createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  List<CardItem> cards = [];
  CardItem? firstOpen;

  @override
  void initState() {
    super.initState();
    generateCards();
  }

  void generateCards() {
    final words = wordSets[widget.wordSetName]!;
    final List<CardItem> temp = [];

    for (var w in words) {
      final id = w["no"]!;
      temp.add(CardItem(text: w["no"]!, pairId: id));
      temp.add(CardItem(text: w["sk"]!, pairId: id));
    }

    temp.shuffle(Random());
    setState(() => cards = temp);
  }

  void handleTap(int index) {
    final card = cards[index];
    if (card.revealed || card.matched) return;

    setState(() => card.revealed = true);

    if (firstOpen == null) {
      firstOpen = card;
    } else {
      if (firstOpen!.pairId == card.pairId &&
          firstOpen!.text != card.text) {
        setState(() {
          card.matched = true;
          firstOpen!.matched = true;
        });
      } else {
        Future.delayed(Duration(milliseconds: 700), () {
          setState(() {
            card.revealed = false;
            firstOpen!.revealed = false;
          });
        });
      }
      firstOpen = null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.wordSetName)),
      body: GridView.builder(
        padding: EdgeInsets.all(16),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 4,
          childAspectRatio: 1,
        ),
        itemCount: cards.length,
        itemBuilder: (context, i) {
          final c = cards[i];
          return GestureDetector(
            onTap: () => handleTap(i),
            child: Container(
              margin: EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: c.matched
                    ? Colors.green.shade300
                    : c.revealed
                        ? Colors.white
                        : Colors.grey.shade400,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Center(
                child: Text(
                  c.revealed || c.matched ? c.text : "",
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
