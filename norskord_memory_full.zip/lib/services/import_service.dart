import 'package:csv/csv.dart';
import '../models/deck.dart';
import 'package:uuid/uuid.dart';

class ImportService {
  static Deck deckFromCsv(String csvContent, String deckName) {
    final rows = CsvToListConverter().convert(csvContent);
    final cards = <CardPair>[];
    for (var row in rows) {
      if (row.length >= 2) {
        final no = row[0].toString().trim();
        final sk = row[1].toString().trim();
        if (no.isNotEmpty && sk.isNotEmpty) {
          cards.add(CardPair(no: no, sk: sk));
        }
      }
    }
    return Deck(id: Uuid().v4(), name: deckName, cards: cards);
  }

  static String exportDeckToCsv(Deck deck) {
    final rows = deck.cards.map((c) => [c.no, c.sk]).toList();
    return const ListToCsvConverter().convert(rows);
  }
}
