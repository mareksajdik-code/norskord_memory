import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import '../models/deck.dart';

class StorageService {
  static const String deckBoxName = 'decks';

  static Future<void> init() async {
    final dir = await getApplicationDocumentsDirectory();
    Hive.init(dir.path);
    Hive.registerAdapter(DeckAdapter());
    await Hive.openBox<Deck>(deckBoxName);
  }

  static Box<Deck> get decksBox => Hive.box<Deck>(deckBoxName);

  static Future<void> saveDeck(Deck deck) async {
    await decksBox.put(deck.id, deck);
  }

  static List<Deck> getAllDecks() {
    return decksBox.values.toList();
  }

  static Future<void> deleteDeck(String id) async {
    await decksBox.delete(id);
  }
}
