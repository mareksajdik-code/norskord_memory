final Map<String, List<Map<String, String>>> wordSets = {
  "Default": [
    {"no": "hus", "sk": "dom"},
    {"no": "bil", "sk": "auto"},
    {"no": "katt", "sk": "mačka"},
    {"no": "hund", "sk": "pes"},
    {"no": "mat", "sk": "jedlo"},
    {"no": "vann", "sk": "voda"},
    {"no": "sol", "sk": "soľ"},
    {"no": "brød", "sk": "chlieb"},
  ],
  "Farby": [
    {"no": "rød", "sk": "červená"},
    {"no": "blå", "sk": "modrá"},
    {"no": "grønn", "sk": "zelená"},
    {"no": "gul", "sk": "žltá"},
  ]
};
