# NorskOrd Memory - Flutter skeleton

This zip contains a minimal Flutter `lib/` skeleton and supporting files to build the NorskOrd Memory app.

## What's included
- `lib/` — Dart source files (main app, screens, models, services, data)
- `assets/sample_deck.csv` — sample CSV deck for import
- `pubspec.yaml` — dependencies and asset declaration
- `README.md` — this file

## Quick start
1. Create a new Flutter app:
   ```
   flutter create norskord_memory
   ```
2. Unzip this archive and **replace** the generated project's `lib/` and `pubspec.yaml` with the ones from this package.
3. Run:
   ```
   cd norskord_memory
   flutter pub get
   flutter run
   ```

## Notes & next steps
- This skeleton implements the core UI and basic logic. For persistence features (Hive adapters), run:
  ```
  flutter pub run build_runner build
  ```
  This requires the `deck.g.dart` generation; the model classes are annotated.
- For iOS builds, use a Mac and set up signing in Xcode.
- I can expand this to a full repo with CI, many decks (200+ words), polished UI, and production-ready build files if you want — say the word and I will add them.


# CI Instructions

## GitHub Actions (Android)
- Workflow: `.github/workflows/android-release.yml`
- Supports signing via GitHub Secrets:
  - ANDROID_KEYSTORE_BASE64
  - ANDROID_KEYSTORE_PASSWORD
  - ANDROID_KEY_ALIAS
  - ANDROID_KEY_PASSWORD

## Codemagic (iOS)
- Uses `codemagic.yaml`
- Requires Apple App Store Connect API key uploaded to Codemagic UI
